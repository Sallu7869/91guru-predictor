const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

app.get('/api/latest-result', async (req, res) => {
  try {
    const response = await axios.get("https://api.bharatclub.net/api/lottery/periods?gameCode=WinGo_1Min&size=1&page=1");
    const data = response.data?.data?.list[0];
    const resultNumber = data?.openNumber;
    const period = data?.period;

    const size = resultNumber > 4 ? "Big" : "Small";

    let color = "";
    if ([0, 5, 10].includes(resultNumber)) color = "Violet";
    else if ([1, 4, 7].includes(resultNumber)) color = "Red";
    else color = "Green";

    res.json({ period, number: resultNumber, size, color });
  } catch (err) {
    res.status(500).json({ error: "Result fetch failed" });
  }
});

app.listen(PORT, () => {
  console.log("Server started on " + PORT);
});
